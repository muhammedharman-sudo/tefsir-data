# Miftah — Kuran Tefsir Uygulaması

Arapça metin, meal ve tefsiri GitHub'a yüklediğiniz JSON dosyalarından çeken,
tamamen tarayıcı içinde çalışan bir Kuran/tefsir uygulaması.

## Nasıl çalışıyor?

- Uygulama tek bir sayfa (index.html) + birkaç JS/CSS dosyasından oluşur, sunucu gerektirmez.
- Arapça / Meal / Tefsir verisi hiçbir zaman uygulamayla birlikte gelmez. Kullanıcı
  hangi sureyi açtıysa, **sadece o surenin dosyası** GitHub'dan indirilir (kapasite sorunu
  yaşanmasın diye tüm Kuran tek seferde çekilmez). İndirilen veri tarayıcıda önbelleğe alınır.
- Favoriler, notlar, konular, kümeler ve kaynak ayarları gibi **kişisel veriler** tarayıcınızın
  IndexedDB'sinde saklanır (localStorage değil — kapasite sorunu yaşamamak için). "Daha › Yedekle"
  sayfasından bunları JSON olarak indirip başka cihaza taşıyabilirsiniz.

## Kurulum

1. Bu klasörün tamamını bir GitHub reposuna yükleyin (örn. `kuran-tefsir-app`).
2. Repo Ayarları (Settings) → Pages → "Deploy from branch" → `main` / `/ (root)` seçip
   kaydedin. Birkaç dakika sonra `https://KULLANICI_ADI.github.io/kuran-tefsir-app/`
   adresinden erişilebilir olur.
3. Arapça/meal/tefsir verilerinizi (bkz. aşağıdaki format) **ayrı bir repoya** ya da aynı
   reponun başka bir klasörüne yükleyin, sonra uygulama içinde **Daha → Arapça/Meal/Tefsir
   Kaynakları** sayfalarından bu klasörlerin "raw" bağlantısını ekleyin.

## Veri formatı

Her sure için, sure numarasına göre adlandırılmış (3 haneli, örn. `001.json`, `114.json`)
ayrı bir JSON dosyası olmalı. Üç kaynak türü birbirinden bağımsızdır — Arapça, meal ve
tefsir farklı repolarda/klasörlerde bile olabilir.

**Arapça** (`data/arabic/001.json`):
```json
{
  "sure_no": 1,
  "sure_adi": "Fatiha",
  "ayetler": [
    { "no": 1, "arapca": "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ" },
    { "no": 2, "arapca": "..." }
  ]
}
```

**Meal** (`data/meal/001.json`):
```json
{
  "sure_no": 1,
  "sure_adi": "Fatiha",
  "kaynak": "Örnek Meal",
  "ayetler": [
    { "no": 1, "meal": "Rahman ve Rahim olan Allah'ın adıyla." }
  ]
}
```

**Tefsir** (`data/tefsir/001.json`):
```json
{
  "sure_no": 1,
  "sure_adi": "Fatiha",
  "kaynak": "Örnek Tefsir",
  "ayetler": [
    { "no": 1, "tefsir": "Besmele ile başlamak..." }
  ]
}
```

`data/sample/` klasöründe Fatiha suresi için doldurulmuş örnek dosyalar var — formatı
görmek için inceleyebilirsiniz.

## Kaynak bağlantısını nasıl bulurum?

GitHub'da bir dosyaya girip "Raw" butonuna bastığınızda çıkan adres şuna benzer:
```
https://raw.githubusercontent.com/kullanici-adi/repo-adi/main/data/arabic/001.json
```
Uygulamaya eklemeniz gereken, dosya adı ve numarası olmadan, **klasör** kısmıdır:
```
https://raw.githubusercontent.com/kullanici-adi/repo-adi/main/data/arabic
```

## Birden fazla kaynak

"Daha" menüsündeki her kaynak sayfasına (Arapça/Meal/Tefsir) birden fazla kaynak
ekleyebilirsiniz (örn. iki farklı tefsir). Eklediklerinizden birini "Aktif Yap" ile
seçili hale getirirsiniz; uygulama her zaman aktif olan kaynağı kullanır.

## Kod yapısı (GitHub üzerinde düzenlemeyi kolaylaştırmak için parçalara ayrıldı)

```
index.html               Sayfa iskeleti, tüm script'lerin dahil edildiği yer
css/style.css             Tüm görsel tasarım

js/data/surahList.js      114 surenin sabit listesi (isim, ayet sayısı, iniş yeri)
js/db.js                  IndexedDB katmanı (favoriler, notlar, konular, kümeler, ayarlar)
js/github.js              GitHub'dan sure verisi çekme + önbellekleme
js/util.js                Toast, modal, favori/not/ilişkili-ayet aksiyonları
js/router.js              Basit hash yönlendirici (#/sure/1 gibi)
js/app.js                 Rota tanımları + üst menü davranışları

js/views/home.js              Ana sayfa
js/views/surahList.js         Sureler listesi
js/views/surahRead.js         Sure okuma (Arapça + Meal + Tefsir)
js/views/topics.js            Konular listesi
js/views/topicDetail.js       Konu detay (Arapça/Meal/Tefsir sekmeleri)
js/views/collections.js       Kümeler listesi
js/views/collectionDetail.js  Küme detay (aralık ekleme + okuma)
js/views/sources.js           Kaynak yönetimi (Daha menüsü)
js/views/favorites.js         Favorilerim
js/views/notes.js             Notlarım
js/views/backup.js            Yedekle / Geri Yükle

data/sample/                  Örnek Fatiha verisi (arabic, meal, tefsir)
```

Bir bölümde değişiklik yapmak istediğinizde sadece ilgili dosyayı düzenlemeniz yeterli;
diğer dosyalara dokunmanıza gerek yok.

## Notlar

- 114 surenin isim/ayet sayısı listesi (`js/data/surahList.js`) yaygın kabul gören sayıma
  göre hazırlanmıştır; küçük bir hata fark ederseniz o dosyadan kolayca düzeltebilirsiniz.
- Konular ve kümeler tamamen sizin oluşturduğunuz, düzenleyebildiğiniz yapılardır —
  uygulama otomatik bir konu ataması yapmaz.
