/*
  github.js — GitHub'a yüklenen JSON dosyalarını çekme katmanı.

  Mantık:
  - Her kaynak (Arapça / Meal / Tefsir) bir "baseUrl" ile tanımlanır.
    Örn: https://raw.githubusercontent.com/KULLANICI/REPO/main/data/arabic
  - Sure verisi bu baseUrl + "/001.json" şeklinde çekilir (bkz. surahList.js -> sureDosyaAdi).
  - Kullanıcı sadece hangi sureye tıkladıysa o dosya indirilir; tüm Kuran asla tek seferde
    indirilmez (kapasite/performans sorunu yaşanmasın diye).
  - Bir kez indirilen sure verisi IndexedDB "cache" tablosunda tutulur, tekrar tekrar
    indirilmez (kullanıcı "Önbelleği Temizle" ile bunu sıfırlayabilir).

  Beklenen JSON formatı (bkz. data/sample klasörü):
  Arapça : { sure_no, sure_adi, ayetler: [{ no, arapca }, ...] }
  Meal   : { sure_no, sure_adi, kaynak, ayetler: [{ no, meal }, ...] }
  Tefsir : { sure_no, sure_adi, kaynak, ayetler: [{ no, tefsir }, ...] }
*/

const GitHubData = {
  // Aktif kaynakların baseUrl'lerini ayarlardan okur
  async getActiveSources() {
    const sources = await DB.getAll("sources");
    const active = await DB.getSetting("activeSources", {});
    const findById = (id) => sources.find((s) => s.id === id) || null;
    return {
      arabic: findById(active.arabic),
      meal: findById(active.meal),
      tefsir: findById(active.tefsir)
    };
  },

  _cacheKey(type, sureNo, sourceId) {
    return `${type}:${sourceId || "none"}:${sureNo}`;
  },

  async _fetchJson(url) {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) {
      throw new Error(`Dosya alınamadı (${res.status}): ${url}`);
    }
    return res.json();
  },

  // type: "arabic" | "meal" | "tefsir"
  async fetchSurah(type, sureNo, source, { useCache = true } = {}) {
    if (!source || !source.baseUrl) {
      throw new Error(
        `${type === "arabic" ? "Arapça" : type === "meal" ? "Meal" : "Tefsir"} için aktif kaynak seçilmemiş. "Daha" menüsünden kaynak seçin.`
      );
    }
    const cacheKey = this._cacheKey(type, sureNo, source.id);

    if (useCache) {
      const cached = await DB.get("cache", cacheKey);
      if (cached) return cached.value;
    }

    const dosyaAdi = sureDosyaAdi(sureNo);
    const url = `${source.baseUrl.replace(/\/$/, "")}/${dosyaAdi}.json`;
    const data = await this._fetchJson(url);

    await DB.put("cache", { key: cacheKey, value: data, fetchedAt: Date.now() });
    return data;
  },

  // Bir sure için üç kaynağı da (varsa) paralel çeker ve ayet no'suna göre birleştirir
  async fetchSurahCombined(sureNo, { useCache = true } = {}) {
    const { arabic, meal, tefsir } = await this.getActiveSources();

    const [arabicData, mealData, tefsirData] = await Promise.allSettled([
      arabic ? this.fetchSurah("arabic", sureNo, arabic, { useCache }) : Promise.resolve(null),
      meal ? this.fetchSurah("meal", sureNo, meal, { useCache }) : Promise.resolve(null),
      tefsir ? this.fetchSurah("tefsir", sureNo, tefsir, { useCache }) : Promise.resolve(null)
    ]);

    const unwrap = (settled) => (settled.status === "fulfilled" ? settled.value : null);
    const errors = [arabicData, mealData, tefsirData]
      .filter((r) => r.status === "rejected")
      .map((r) => r.reason?.message || String(r.reason));

    const a = unwrap(arabicData);
    const m = unwrap(mealData);
    const t = unwrap(tefsirData);

    const ayetSayisi = (a?.ayetler?.length || m?.ayetler?.length || t?.ayetler?.length || 0);
    const ayetler = [];
    for (let i = 1; i <= ayetSayisi; i++) {
      ayetler.push({
        no: i,
        arapca: a?.ayetler?.find((x) => x.no === i)?.arapca || null,
        meal: m?.ayetler?.find((x) => x.no === i)?.meal || null,
        tefsir: t?.ayetler?.find((x) => x.no === i)?.tefsir || null
      });
    }

    return {
      sure_no: sureNo,
      sure_adi: a?.sure_adi || m?.sure_adi || t?.sure_adi || (SURAH_LIST.find((s) => s.no === sureNo)?.ad ?? ""),
      ayetler,
      errors
    };
  },

  async clearCache() {
    await DB.clear("cache");
  }
};
