/* views/notes.js — Tüm ayet notlarının listelendiği sayfa */

const ViewNotes = {
  async render() {
    const app = document.getElementById("app");
    const notes = await DB.getAll("notes");
    notes.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    app.innerHTML = `
      <p class="page-eyebrow">Daha › Notlarım</p>
      <h1 class="page-title">Notlarım</h1>
      <p class="page-sub">${notes.length} not eklediniz.</p>
      <div id="notesList"></div>
    `;

    const listEl = document.getElementById("notesList");
    if (notes.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
          <h4>Henüz not eklemediniz</h4>
          <p>Bir sureyi açıp ayetin altındaki "Not Ekle" butonuna basarak başlayabilirsiniz.</p>
          <a class="btn" href="#/sureler">Surelere Git</a>
        </div>
      `;
      return;
    }

    listEl.innerHTML = notes.map((n) => `
      <a class="list-card" href="#/sure/${n.sure}#ayet-${n.ayet}" style="display:block;margin-bottom:12px;">
        <div class="lc-no">${escapeHtml(n.sureAdi)} · ${n.ayet}. Ayet</div>
        <div style="font-size:14.5px;color:var(--text-light);margin:6px 0;line-height:1.6;">${escapeHtml(n.text)}</div>
        <div class="lc-meta">${new Date(n.createdAt).toLocaleString("tr-TR")}</div>
      </a>
    `).join("");
  }
};
