/* views/collectionDetail.js — Bir kümenin detay sayfası: aralık ekleme + birleşik okuma */

const ViewCollectionDetail = {
  async render(collId) {
    const app = document.getElementById("app");
    const coll = await DB.get("collections", collId);
    if (!coll) {
      app.innerHTML = `<div class="empty-state"><h4>Küme bulunamadı</h4><a class="btn" href="#/kumeler">Kümelere Dön</a></div>`;
      return;
    }
    coll.items = coll.items || [];

    app.innerHTML = `
      <a class="back-link" href="#/kumeler">← Kümeler</a>
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:20px;flex-wrap:wrap;">
        <div>
          <p class="page-eyebrow">Küme</p>
          <h1 class="page-title" id="collTitle">${escapeHtml(coll.name)}</h1>
          <p class="page-sub">${coll.items.length} aralık eklendi.</p>
        </div>
        <button class="icon-btn" id="deleteCollBtn" style="color:var(--maroon);border-color:var(--maroon);">Kümeyi Sil</button>
      </div>

      <button class="btn" id="addRangeBtn" style="margin-bottom:18px;">+ Sure / Ayet Aralığı Ekle</button>

      <div class="panel" id="itemsPanel" style="margin-bottom:30px;"></div>

      <div class="hizb-divider"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg></div>

      <div id="readArea"></div>
    `;

    document.getElementById("deleteCollBtn").addEventListener("click", () => {
      openModal(`
        <h3>Kümeyi Sil</h3>
        <p style="font-size:14px;">"${escapeHtml(coll.name)}" kümesini silmek istediğinize emin misiniz?</p>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn btn-danger" id="confirmDel">Sil</button>
        </div>
      `, {
        onMount: (m, close) => {
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#confirmDel").addEventListener("click", async () => {
            await DB.delete("collections", collId);
            close();
            toast("Küme silindi");
            location.hash = "#/kumeler";
          });
        }
      });
    });

    function renderItemsPanel() {
      const panel = document.getElementById("itemsPanel");
      if (coll.items.length === 0) {
        panel.innerHTML = `<p style="color:var(--text-muted-light);font-size:14px;margin:0;">Henüz aralık eklenmedi.</p>`;
        return;
      }
      panel.innerHTML = `
        <div class="range-list">
          ${coll.items.map((it, idx) => `
            <div class="range-item" style="background:var(--ink);border-color:rgba(201,162,39,0.2);color:var(--text-light);">
              <span>${escapeHtml(it.sureAdi)} — ${it.ayetStart === it.ayetEnd ? `${it.ayetStart}. ayet` : `${it.ayetStart}–${it.ayetEnd}. ayetler`}</span>
              <button data-idx="${idx}" class="del-range-btn" style="color:var(--maroon);">✕</button>
            </div>
          `).join("")}
        </div>
      `;
      panel.querySelectorAll(".del-range-btn").forEach((btn) => {
        btn.addEventListener("click", async () => {
          coll.items.splice(parseInt(btn.dataset.idx, 10), 1);
          await DB.put("collections", coll);
          renderItemsPanel();
          renderReadArea();
          toast("Aralık kaldırıldı");
        });
      });
    }
    renderItemsPanel();

    document.getElementById("addRangeBtn").addEventListener("click", () => {
      const options = SURAH_LIST.map((s) => `<option value="${s.no}">${s.no}. ${s.ad} (${s.ayet} ayet)</option>`).join("");
      openModal(`
        <h3>Sure / Ayet Aralığı Ekle</h3>
        <div class="field"><label>Sure</label><select id="rgSure">${options}</select></div>
        <div class="range-row">
          <div class="field"><label>Başlangıç Ayeti</label><input type="text" id="rgStart" placeholder="1" /></div>
          <div class="field"><label>Bitiş Ayeti</label><input type="text" id="rgEnd" placeholder="5 (tek ayet için boş bırakın)" /></div>
        </div>
        <p style="font-size:12.5px;color:#6B6350;">Birden fazla aralık eklemek için bu işlemi tekrarlayabilirsiniz.</p>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn" id="rgSave">Ekle</button>
        </div>
      `, {
        onMount: (m, close) => {
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#rgSave").addEventListener("click", async () => {
            const sure = parseInt(m.querySelector("#rgSure").value, 10);
            const start = parseInt(m.querySelector("#rgStart").value, 10);
            const endRaw = m.querySelector("#rgEnd").value.trim();
            const end = endRaw ? parseInt(endRaw, 10) : start;
            if (!sure || !start || !end || end < start) { toast("Geçerli bir ayet aralığı girin"); return; }
            const sureAdi = SURAH_LIST.find((s) => s.no === sure)?.ad || "";
            coll.items.push({ sure, sureAdi, ayetStart: start, ayetEnd: end });
            await DB.put("collections", coll);
            close();
            renderItemsPanel();
            renderReadArea();
            toast("Aralık eklendi");
          });
        }
      });
    });

    async function renderReadArea() {
      const readArea = document.getElementById("readArea");
      if (coll.items.length === 0) {
        readArea.innerHTML = "";
        return;
      }
      readArea.innerHTML = `<div class="loader"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg><span>Ayetler getiriliyor…</span></div>`;

      const sureNos = [...new Set(coll.items.map((it) => it.sure))];
      const sureDataMap = {};
      try {
        await Promise.all(sureNos.map(async (no) => {
          sureDataMap[no] = await GitHubData.fetchSurahCombined(no);
        }));
      } catch (err) {
        readArea.innerHTML = `<div class="empty-state"><h4>Veri alınamadı</h4><p>${escapeHtml(err.message)}</p></div>`;
        return;
      }

      readArea.innerHTML = "";
      for (const it of coll.items) {
        const sureData = sureDataMap[it.sure];
        const heading = document.createElement("h3");
        heading.style.cssText = "font-family:var(--font-display);color:var(--parchment);font-size:20px;margin:26px 0 6px;";
        heading.textContent = `${it.sureAdi} — ${it.ayetStart === it.ayetEnd ? `${it.ayetStart}. ayet` : `${it.ayetStart}-${it.ayetEnd}. ayetler`}`;
        readArea.appendChild(heading);

        for (let n = it.ayetStart; n <= it.ayetEnd; n++) {
          const ayetData = sureData?.ayetler.find((a) => a.no === n);
          const card = document.createElement("div");
          card.className = "ayet-card";
          let body = `<div class="ayet-head"><span class="ayet-no">${n}</span></div>`;
          if (!ayetData) {
            body += `<p style="color:var(--text-muted-light);font-size:13.5px;">Bu ayet için veri bulunamadı.</p>`;
          } else {
            if (ayetData.arapca) body += `<div class="ayet-arabic">${escapeHtml(ayetData.arapca)}</div>`;
            if (ayetData.meal) body += `<div class="ayet-meal">${escapeHtml(ayetData.meal)}</div>`;
            if (ayetData.tefsir) body += `<div class="ayet-tefsir"><span class="tefsir-kaynak">Tefsir</span>${escapeHtml(ayetData.tefsir)}</div>`;
          }
          card.innerHTML = body;
          readArea.appendChild(card);
          if (ayetData) await renderAyetActions(card, { sure: it.sure, ayet: n, sureAdi: it.sureAdi });
        }
      }
    }

    renderReadArea();
  }
};
