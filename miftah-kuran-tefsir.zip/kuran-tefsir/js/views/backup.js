/* views/backup.js — Kişisel verilerin (favoriler, notlar, konular, kümeler, kaynaklar)
   JSON olarak dışa aktarılması ve geri yüklenmesi. localStorage yerine IndexedDB
   kullanıldığı için bu sayfa, cihazlar arası taşımanın tek yoludur. */

const ViewBackup = {
  async render() {
    const app = document.getElementById("app");
    app.innerHTML = `
      <p class="page-eyebrow">Daha › Yedekle</p>
      <h1 class="page-title">Yedekle / Geri Yükle</h1>
      <p class="page-sub">Favorileriniz, notlarınız, konularınız, kümeleriniz ve kaynak ayarlarınız bu cihazda saklanır. Başka bir cihaza taşımak veya kaybolmaması için düzenli olarak yedek indirin.</p>

      <div class="panel" style="margin-bottom:20px;">
        <h3 style="font-family:var(--font-display);margin:0 0 6px;color:var(--parchment);font-size:20px;">Yedek İndir</h3>
        <p style="font-size:13.5px;color:var(--text-muted-light);margin:0 0 16px;">Tüm kişisel verilerinizi tek bir JSON dosyası olarak indirin.</p>
        <button class="btn" id="exportBtn">Yedek Dosyasını İndir</button>
      </div>

      <div class="panel">
        <h3 style="font-family:var(--font-display);margin:0 0 6px;color:var(--parchment);font-size:20px;">Yedekten Geri Yükle</h3>
        <p style="font-size:13.5px;color:var(--text-muted-light);margin:0 0 16px;">Daha önce indirdiğiniz bir yedek dosyasını seçin. Bu işlem, bu cihazdaki mevcut verilerin üzerine yazar.</p>
        <input type="file" id="importFile" accept="application/json" style="margin-bottom:14px;" />
        <br/>
        <button class="btn btn-outline" id="importBtn">Geri Yükle</button>
      </div>
    `;

    document.getElementById("exportBtn").addEventListener("click", async () => {
      const data = await DB.exportAll();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const tarih = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `miftah-yedek-${tarih}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast("Yedek dosyası indirildi");
    });

    document.getElementById("importBtn").addEventListener("click", async () => {
      const fileInput = document.getElementById("importFile");
      const file = fileInput.files[0];
      if (!file) { toast("Önce bir dosya seçin"); return; }

      try {
        const text = await file.text();
        const data = JSON.parse(text);
        openModal(`
          <h3>Geri Yükleme Onayı</h3>
          <p style="font-size:14px;">Bu cihazdaki mevcut favoriler, notlar, konular, kümeler ve kaynak ayarlarının üzerine yazılacak. Devam etmek istiyor musunuz?</p>
          <div class="modal-actions">
            <button class="btn btn-outline" data-close>Vazgeç</button>
            <button class="btn btn-danger" id="confirmImport">Geri Yükle</button>
          </div>
        `, {
          onMount: (m, close) => {
            m.querySelector("[data-close]").addEventListener("click", close);
            m.querySelector("#confirmImport").addEventListener("click", async () => {
              try {
                await DB.importAll(data, { overwrite: true });
                close();
                toast("Veriler geri yüklendi");
                location.hash = "#/home";
              } catch (err) {
                toast("Hata: " + err.message);
              }
            });
          }
        });
      } catch (err) {
        toast("Dosya okunamadı: " + err.message);
      }
    });
  }
};
