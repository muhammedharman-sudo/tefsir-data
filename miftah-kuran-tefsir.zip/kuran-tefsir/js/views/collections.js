/* views/collections.js — Kümeler listesi (kişisel derlemeler) */

const ViewCollections = {
  async render() {
    const app = document.getElementById("app");
    const collections = await DB.getAll("collections");
    collections.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    app.innerHTML = `
      <p class="page-eyebrow">Derleme</p>
      <h1 class="page-title">Kümeler</h1>
      <p class="page-sub">Farklı surelerden seçtiğiniz ayet aralıklarını bir araya getirin. Örneğin bir sohbet veya ders için okuma listesi oluşturabilirsiniz.</p>

      <button class="btn" id="newCollectionBtn">+ Yeni Küme</button>

      <div class="hizb-divider"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg></div>

      <div id="collGrid" class="grid-list"></div>
    `;

    const grid = document.getElementById("collGrid");
    function renderGrid() {
      if (collections.length === 0) {
        grid.innerHTML = `
          <div class="empty-state" style="grid-column:1/-1;">
            <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
            <h4>Henüz küme oluşturmadınız</h4>
            <p>Bir küme oluşturup içine sure + ayet aralığı ekleyerek başlayın.</p>
          </div>
        `;
        return;
      }
      grid.innerHTML = collections.map((c) => `
        <a class="list-card" href="#/kume/${c.id}">
          <div class="lc-no">KÜME</div>
          <div class="lc-title">${escapeHtml(c.name)}</div>
          <div class="lc-meta">${(c.items || []).length} aralık</div>
        </a>
      `).join("");
    }
    renderGrid();

    document.getElementById("newCollectionBtn").addEventListener("click", () => {
      openModal(`
        <h3>Yeni Küme</h3>
        <div class="field">
          <label>Küme Adı</label>
          <input type="text" id="collName" placeholder="Örn: Cuma Sohbeti Ayetleri" />
        </div>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn" id="createCollBtn">Oluştur</button>
        </div>
      `, {
        onMount: (m, close) => {
          const input = m.querySelector("#collName");
          input.focus();
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#createCollBtn").addEventListener("click", async () => {
            const name = input.value.trim();
            if (!name) return;
            const id = uid("coll");
            await DB.put("collections", { id, name, items: [], createdAt: Date.now() });
            close();
            toast("Küme oluşturuldu");
            location.hash = `#/kume/${id}`;
          });
          input.addEventListener("keydown", (e) => { if (e.key === "Enter") m.querySelector("#createCollBtn").click(); });
        }
      });
    });
  }
};
