/* views/home.js — Ana sayfa: üç büyük bölüm kartı + kısa erişim */

const ViewHome = {
  async render() {
    const app = document.getElementById("app");

    const [topics, collections, favorites] = await Promise.all([
      DB.getAll("topics"),
      DB.getAll("collections"),
      DB.getAll("favorites")
    ]);

    app.innerHTML = `
      <p class="page-eyebrow">Miftah</p>
      <h1 class="page-title">Kuran-ı Kerim Tefsir</h1>
      <p class="page-sub">Arapça metin, meal ve tefsiri bir arada okuyun; ayetleri konularına göre keşfedin, kendi kümelerinizi ve notlarınızı oluşturun.</p>

      <div class="hero-cards">
        <a class="hero-card" href="#/sureler">
          <svg class="corner" viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
          <div class="num">114 Sure</div>
          <h3>Sureler</h3>
          <p>Sure sure oku; her ayetin Arapçası, meali ve tefsiri birlikte.</p>
        </a>
        <a class="hero-card" href="#/kumeler">
          <svg class="corner" viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
          <div class="num">${collections.length} Küme</div>
          <h3>Kümeler</h3>
          <p>Farklı surelerden seçtiğiniz ayet aralıklarını bir araya getirin.</p>
        </a>
        <a class="hero-card" href="#/konular">
          <svg class="corner" viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
          <div class="num">${topics.length} Konu</div>
          <h3>Konular</h3>
          <p>Ayetleri kendi belirlediğiniz konu başlıklarına göre gruplayın.</p>
        </a>
      </div>

      <div class="hizb-divider"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg></div>

      <div class="panel">
        <h3 style="font-family:var(--font-display);margin:0 0 4px;color:var(--parchment);font-size:20px;">Favorileriniz</h3>
        ${favorites.length === 0 ? `
          <p style="color:var(--text-muted-light);font-size:14px;margin:8px 0 0;">Henüz favori ayet eklemediniz. Bir sureyi açıp ayetin altındaki "Favori" butonuna basarak başlayabilirsiniz.</p>
        ` : `
          <div class="grid-list" style="margin-top:14px;">
            ${favorites.slice(0, 6).map((f) => `
              <a class="list-card" href="#/sure/${f.sure}#ayet-${f.ayet}">
                <div class="lc-no">${escapeHtml(f.sureAdi)}</div>
                <div class="lc-title">${f.ayet}. Ayet</div>
              </a>
            `).join("")}
          </div>
          ${favorites.length > 6 ? `<div style="margin-top:14px;"><a class="back-link" href="#/favoriler">Tüm favorileri gör →</a></div>` : ""}
        `}
      </div>
    `;
  }
};
