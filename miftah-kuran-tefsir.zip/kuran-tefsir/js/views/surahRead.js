/* views/surahRead.js — Tek bir surenin ayet ayet okunduğu sayfa.
   Arapça + Meal + Tefsir aynı anda, GitHub kaynaklarından çekilerek gösterilir. */

const ViewSurahRead = {
  async render(sureNo) {
    const app = document.getElementById("app");
    const sureInfo = SURAH_LIST.find((s) => s.no === sureNo);
    if (!sureInfo) {
      app.innerHTML = `<div class="empty-state"><h4>Sure bulunamadı</h4></div>`;
      return;
    }

    const { arabic, meal, tefsir } = await GitHubData.getActiveSources();
    if (!arabic && !meal && !tefsir) {
      app.innerHTML = `
        <a class="back-link" href="#/sureler">← Sureler</a>
        <div class="empty-state">
          <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
          <h4>Henüz kaynak eklenmedi</h4>
          <p>Ayetleri okuyabilmek için önce "Daha" menüsünden Arapça, Meal ve Tefsir kaynaklarınızı (GitHub bağlantılarınızı) ekleyip aktif hale getirin.</p>
          <a class="btn" href="#/kaynaklar/arabic">Kaynak Ekle</a>
        </div>
      `;
      return;
    }

    app.innerHTML = `
      <a class="back-link" href="#/sureler">← Sureler</a>
      <p class="page-eyebrow">${sureInfo.no}. Sure · ${sureInfo.yer}</p>
      <h1 class="page-title">${escapeHtml(sureInfo.ad)}</h1>
      <p class="page-sub">${sureInfo.ayet} ayet</p>
      <div id="ayetler"></div>
    `;

    const container = document.getElementById("ayetler");
    container.innerHTML = `<div class="loader"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg><span>${escapeHtml(sureInfo.ad)} suresi GitHub'dan getiriliyor…</span></div>`;

    let data;
    try {
      data = await GitHubData.fetchSurahCombined(sureNo);
    } catch (err) {
      container.innerHTML = `<div class="empty-state"><h4>Veri alınamadı</h4><p>${escapeHtml(err.message)}</p></div>`;
      return;
    }

    if (data.errors && data.errors.length) {
      toast("Bazı kaynaklardan veri alınamadı, eksik görünebilir.");
    }

    if (!data.ayetler.length) {
      container.innerHTML = `<div class="empty-state"><h4>Bu sure için veri bulunamadı</h4><p>GitHub reponuzda ${sureDosyaAdi(sureNo)}.json dosyasının bulunduğundan emin olun.</p></div>`;
      return;
    }

    container.innerHTML = "";
    for (const ayet of data.ayetler) {
      const card = document.createElement("div");
      card.className = "ayet-card";
      card.id = `ayet-${ayet.no}`;
      card.innerHTML = `
        <div class="ayet-head">
          <span class="ayet-no">${ayet.no}</span>
        </div>
        ${ayet.arapca ? `<div class="ayet-arabic">${escapeHtml(ayet.arapca)}</div>` : ""}
        ${ayet.meal ? `<div class="ayet-meal">${escapeHtml(ayet.meal)}</div>` : ""}
        ${ayet.tefsir ? `<div class="ayet-tefsir"><span class="tefsir-kaynak">Tefsir</span>${escapeHtml(ayet.tefsir)}</div>` : ""}
      `;
      container.appendChild(card);
      await renderAyetActions(card, { sure: sureNo, ayet: ayet.no, sureAdi: sureInfo.ad });
    }

    // Eğer URL'de #ayet-N varsa oraya kaydır
    const targetHash = location.hash.split("#")[2];
    if (targetHash) {
      const el = document.getElementById(`ayet-${targetHash.replace("ayet-", "")}`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }
};
