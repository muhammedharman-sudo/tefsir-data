/* views/topics.js — Kullanıcının kendi belirlediği konu başlıkları listesi (düzenlenebilir) */

const ViewTopics = {
  async render() {
    const app = document.getElementById("app");
    const topics = await DB.getAll("topics");
    topics.sort((a, b) => (a.name || "").localeCompare(b.name || "", "tr"));

    app.innerHTML = `
      <p class="page-eyebrow">Keşfet</p>
      <h1 class="page-title">Konular</h1>
      <p class="page-sub">Ayetleri kendi belirlediğiniz konu başlıkları altında toplayın. Bir konuya tıklayınca o konuya eklediğiniz ayetleri Arapça, Meal ve Tefsir sekmeleriyle görürsünüz.</p>

      <button class="btn" id="newTopicBtn">+ Yeni Konu</button>

      <div class="hizb-divider"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg></div>

      <div id="topicGrid" class="grid-list"></div>
    `;

    const grid = document.getElementById("topicGrid");
    function renderGrid() {
      if (topics.length === 0) {
        grid.innerHTML = `
          <div class="empty-state" style="grid-column:1/-1;">
            <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
            <h4>Henüz konu oluşturmadınız</h4>
            <p>Örneğin "Sabır", "Aile", "Kıssalar" gibi bir konu açıp, sure okurken veya buradan ayet ekleyebilirsiniz.</p>
          </div>
        `;
        return;
      }
      grid.innerHTML = topics.map((t) => `
        <a class="list-card" href="#/konu/${t.id}">
          <div class="lc-no">KONU</div>
          <div class="lc-title">${escapeHtml(t.name)}</div>
          <div class="lc-meta">${(t.ayetler || []).length} ayet</div>
        </a>
      `).join("");
    }
    renderGrid();

    document.getElementById("newTopicBtn").addEventListener("click", () => {
      openModal(`
        <h3>Yeni Konu</h3>
        <div class="field">
          <label>Konu Adı</label>
          <input type="text" id="topicName" placeholder="Örn: Sabır" />
        </div>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn" id="createTopicBtn">Oluştur</button>
        </div>
      `, {
        onMount: (modalEl, close) => {
          const input = modalEl.querySelector("#topicName");
          input.focus();
          modalEl.querySelector("[data-close]").addEventListener("click", close);
          modalEl.querySelector("#createTopicBtn").addEventListener("click", async () => {
            const name = input.value.trim();
            if (!name) return;
            const id = uid("topic");
            await DB.put("topics", { id, name, ayetler: [], createdAt: Date.now() });
            close();
            toast("Konu oluşturuldu");
            location.hash = `#/konu/${id}`;
          });
          input.addEventListener("keydown", (e) => { if (e.key === "Enter") modalEl.querySelector("#createTopicBtn").click(); });
        }
      });
    });
  }
};
