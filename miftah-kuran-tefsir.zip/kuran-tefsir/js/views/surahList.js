/* views/surahList.js — 114 surenin listelendiği sayfa (arama destekli) */

const ViewSurahList = {
  async render() {
    const app = document.getElementById("app");
    app.innerHTML = `
      <p class="page-eyebrow">Okuma</p>
      <h1 class="page-title">Sureler</h1>
      <p class="page-sub">Bir sureye tıklayarak Arapça metnini, mealini ve tefsirini birlikte okuyun.</p>

      <div class="field" style="max-width:340px;margin-bottom:26px;">
        <input type="search" id="sureAra" placeholder="Sure adı veya numarası ara…" />
      </div>

      <div class="grid-list" id="sureGrid"></div>
    `;

    const grid = document.getElementById("sureGrid");

    function renderList(list) {
      if (list.length === 0) {
        grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><h4>Sonuç bulunamadı</h4><p>Farklı bir arama deneyin.</p></div>`;
        return;
      }
      grid.innerHTML = list.map((s) => `
        <a class="list-card" href="#/sure/${s.no}">
          <div class="lc-no">${String(s.no).padStart(3, "0")}</div>
          <div class="lc-title">${escapeHtml(s.ad)}</div>
          <div class="lc-meta">${s.ayet} ayet · ${s.yer}</div>
        </a>
      `).join("");
    }

    renderList(SURAH_LIST);

    document.getElementById("sureAra").addEventListener("input", (e) => {
      const q = e.target.value.trim().toLocaleLowerCase("tr");
      const filtered = SURAH_LIST.filter((s) =>
        s.ad.toLocaleLowerCase("tr").includes(q) || String(s.no) === q
      );
      renderList(filtered);
    });
  }
};
