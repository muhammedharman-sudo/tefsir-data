/* views/topicDetail.js — Bir konunun detay sayfası.
   Üç sekme: Arapça (sadece Arapça), Meal (sadece meal), Tefsir (Arapça+Meal+Tefsir hepsi). */

const ViewTopicDetail = {
  async render(topicId) {
    const app = document.getElementById("app");
    const topic = await DB.get("topics", topicId);
    if (!topic) {
      app.innerHTML = `<div class="empty-state"><h4>Konu bulunamadı</h4><a class="btn" href="#/konular">Konulara Dön</a></div>`;
      return;
    }
    topic.ayetler = topic.ayetler || [];

    app.innerHTML = `
      <a class="back-link" href="#/konular">← Konular</a>
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:20px;flex-wrap:wrap;">
        <div>
          <p class="page-eyebrow">Konu</p>
          <h1 class="page-title" id="topicTitle">${escapeHtml(topic.name)}</h1>
          <p class="page-sub">${topic.ayetler.length} ayet bu konuya eklendi.</p>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0;">
          <button class="icon-btn" id="renameBtn">Yeniden Adlandır</button>
          <button class="icon-btn" id="deleteTopicBtn" style="color:var(--maroon);border-color:var(--maroon);">Konuyu Sil</button>
        </div>
      </div>

      <button class="btn" id="addAyetBtn" style="margin-bottom:10px;">+ Ayet Ekle</button>

      <div class="tabs">
        <button class="tab-btn active" data-tab="arabic">Arapça</button>
        <button class="tab-btn" data-tab="meal">Meal</button>
        <button class="tab-btn" data-tab="tefsir">Tefsir</button>
      </div>

      <div id="tabContent"></div>
    `;

    document.getElementById("renameBtn").addEventListener("click", () => {
      openModal(`
        <h3>Konuyu Yeniden Adlandır</h3>
        <div class="field"><label>Konu Adı</label><input type="text" id="rnInput" value="${escapeHtml(topic.name)}" /></div>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn" id="rnSave">Kaydet</button>
        </div>
      `, {
        onMount: (m, close) => {
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#rnSave").addEventListener("click", async () => {
            const val = m.querySelector("#rnInput").value.trim();
            if (!val) return;
            topic.name = val;
            await DB.put("topics", topic);
            document.getElementById("topicTitle").textContent = val;
            close();
            toast("Konu adı güncellendi");
          });
        }
      });
    });

    document.getElementById("deleteTopicBtn").addEventListener("click", () => {
      openModal(`
        <h3>Konuyu Sil</h3>
        <p style="font-size:14px;">"${escapeHtml(topic.name)}" konusunu ve içindeki ayet eşlemelerini silmek istediğinize emin misiniz? Bu işlem geri alınamaz.</p>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn btn-danger" id="confirmDel">Sil</button>
        </div>
      `, {
        onMount: (m, close) => {
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#confirmDel").addEventListener("click", async () => {
            await DB.delete("topics", topicId);
            close();
            toast("Konu silindi");
            location.hash = "#/konular";
          });
        }
      });
    });

    document.getElementById("addAyetBtn").addEventListener("click", () => {
      const options = SURAH_LIST.map((s) => `<option value="${s.no}">${s.no}. ${s.ad}</option>`).join("");
      openModal(`
        <h3>Konuya Ayet Ekle</h3>
        <div class="range-row">
          <div class="field"><label>Sure</label><select id="addSure">${options}</select></div>
          <div class="field"><label>Ayet No</label><input type="text" id="addAyet" placeholder="Örn: 153" /></div>
        </div>
        <p style="font-size:12.5px;color:#6B6350;">Birden fazla ayet eklemek için bu işlemi tekrarlayabilirsiniz.</p>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn" id="addSave">Ekle</button>
        </div>
      `, {
        onMount: (m, close) => {
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#addSave").addEventListener("click", async () => {
            const sure = parseInt(m.querySelector("#addSure").value, 10);
            const ayet = parseInt(m.querySelector("#addAyet").value, 10);
            if (!sure || !ayet) { toast("Sure ve ayet numarası gerekli"); return; }
            const already = topic.ayetler.find((x) => x.sure === sure && x.ayet === ayet);
            if (already) { toast("Bu ayet zaten konuda ekli"); close(); return; }
            const sureAdi = SURAH_LIST.find((s) => s.no === sure)?.ad || "";
            topic.ayetler.push({ sure, ayet, sureAdi });
            await DB.put("topics", topic);
            close();
            toast("Ayet eklendi");
            ViewTopicDetail.render(topicId);
          });
        }
      });
    });

    // ---- Sekmeler ----
    const tabBtns = app.querySelectorAll(".tab-btn");
    let activeTab = "arabic";
    tabBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        tabBtns.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        activeTab = btn.dataset.tab;
        renderTabContent(activeTab);
      });
    });

    const tabContent = document.getElementById("tabContent");

    async function renderTabContent(tab) {
      if (topic.ayetler.length === 0) {
        tabContent.innerHTML = `
          <div class="empty-state">
            <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
            <h4>Bu konuya henüz ayet eklenmedi</h4>
            <p>Yukarıdaki "Ayet Ekle" butonunu kullanarak başlayın.</p>
          </div>
        `;
        return;
      }

      tabContent.innerHTML = `<div class="loader"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg><span>Ayetler getiriliyor…</span></div>`;

      // Sure bazında grupla, her sureyi bir kez çek
      const sureNos = [...new Set(topic.ayetler.map((x) => x.sure))];
      const sureDataMap = {};
      try {
        await Promise.all(sureNos.map(async (no) => {
          sureDataMap[no] = await GitHubData.fetchSurahCombined(no);
        }));
      } catch (err) {
        tabContent.innerHTML = `<div class="empty-state"><h4>Veri alınamadı</h4><p>${escapeHtml(err.message)}</p></div>`;
        return;
      }

      tabContent.innerHTML = "";
      for (const ref of topic.ayetler) {
        const sureData = sureDataMap[ref.sure];
        const ayetData = sureData?.ayetler.find((a) => a.no === ref.ayet);

        const card = document.createElement("div");
        card.className = "ayet-card";

        let body = `
          <div class="ayet-head">
            <span class="ayet-no">${ref.ayet}</span>
            <span style="font-size:13px;color:var(--sage);font-weight:600;">${escapeHtml(ref.sureAdi)}</span>
            <button class="icon-btn remove-from-topic" data-sure="${ref.sure}" data-ayet="${ref.ayet}" style="margin-left:auto;">Konudan Çıkar</button>
          </div>
        `;
        if (!ayetData) {
          body += `<p style="color:var(--text-muted-light);font-size:13.5px;">Bu ayet için veri bulunamadı.</p>`;
        } else {
          if (tab === "arabic" && ayetData.arapca) {
            body += `<div class="ayet-arabic">${escapeHtml(ayetData.arapca)}</div>`;
          }
          if (tab === "meal" && ayetData.meal) {
            body += `<div class="ayet-meal">${escapeHtml(ayetData.meal)}</div>`;
          }
          if (tab === "tefsir") {
            if (ayetData.arapca) body += `<div class="ayet-arabic">${escapeHtml(ayetData.arapca)}</div>`;
            if (ayetData.meal) body += `<div class="ayet-meal">${escapeHtml(ayetData.meal)}</div>`;
            if (ayetData.tefsir) body += `<div class="ayet-tefsir"><span class="tefsir-kaynak">Tefsir</span>${escapeHtml(ayetData.tefsir)}</div>`;
          }
        }
        card.innerHTML = body;
        tabContent.appendChild(card);

        if (ayetData) {
          await renderAyetActions(card, { sure: ref.sure, ayet: ref.ayet, sureAdi: ref.sureAdi });
        }
      }

      tabContent.querySelectorAll(".remove-from-topic").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const sure = parseInt(btn.dataset.sure, 10);
          const ayet = parseInt(btn.dataset.ayet, 10);
          topic.ayetler = topic.ayetler.filter((x) => !(x.sure === sure && x.ayet === ayet));
          await DB.put("topics", topic);
          toast("Ayet konudan çıkarıldı");
          ViewTopicDetail.render(topicId);
        });
      });
    }

    renderTabContent(activeTab);
  }
};
