/* views/favorites.js — Tüm favori ayetlerin listelendiği sayfa */

const ViewFavorites = {
  async render() {
    const app = document.getElementById("app");
    const favorites = await DB.getAll("favorites");
    favorites.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    app.innerHTML = `
      <p class="page-eyebrow">Daha › Favorilerim</p>
      <h1 class="page-title">Favorilerim</h1>
      <p class="page-sub">${favorites.length} ayeti favorilerinize eklediniz.</p>
      <div id="favGrid" class="grid-list"></div>
    `;

    const grid = document.getElementById("favGrid");
    if (favorites.length === 0) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column:1/-1;">
          <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
          <h4>Henüz favori ayetiniz yok</h4>
          <p>Bir sureyi açıp ayetin altındaki "Favori" butonuna basarak ekleyebilirsiniz.</p>
          <a class="btn" href="#/sureler">Surelere Git</a>
        </div>
      `;
      return;
    }

    grid.innerHTML = favorites.map((f) => `
      <a class="list-card" href="#/sure/${f.sure}#ayet-${f.ayet}">
        <div class="lc-no">${escapeHtml(f.sureAdi)}</div>
        <div class="lc-title">${f.ayet}. Ayet</div>
        <div class="lc-meta">${new Date(f.createdAt).toLocaleDateString("tr-TR")}</div>
      </a>
    `).join("");
  }
};
