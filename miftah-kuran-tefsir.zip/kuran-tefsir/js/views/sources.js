/* views/sources.js — "Daha" menüsündeki kaynak yönetim sayfaları.
   Kullanıcı burada GitHub raw klasör bağlantılarını (baseUrl) ekler,
   birden fazla kaynak arasından hangisinin aktif kullanılacağını seçer. */

const SOURCE_LABELS = {
  arabic: { title: "Arapça Kaynakları", desc: "Ayetlerin Arapça metnini içeren GitHub klasör bağlantıları." },
  meal: { title: "Meal Kaynakları", desc: "Ayet meallerini içeren GitHub klasör bağlantıları." },
  tefsir: { title: "Tefsir Kaynakları", desc: "Ayet tefsirlerini içeren GitHub klasör bağlantıları." }
};

const ViewSources = {
  async render(type) {
    const app = document.getElementById("app");
    const label = SOURCE_LABELS[type];
    if (!label) {
      app.innerHTML = `<div class="empty-state"><h4>Geçersiz kaynak türü</h4></div>`;
      return;
    }

    const allSources = await DB.getAll("sources");
    const sources = allSources.filter((s) => s.type === type);
    const activeSources = await DB.getSetting("activeSources", {});

    app.innerHTML = `
      <p class="page-eyebrow">Daha › Kaynaklar</p>
      <h1 class="page-title">${label.title}</h1>
      <p class="page-sub">${label.desc} Dosya adları sure numarasına göre olmalı, örn: <code>001.json</code>, <code>002.json</code> ... Aşağıya reponuzun ilgili klasörünün <b>raw.githubusercontent.com</b> bağlantısını ekleyin.</p>

      <div class="chip-row">
        <a class="chip ${type === "arabic" ? "active" : ""}" href="#/kaynaklar/arabic">Arapça</a>
        <a class="chip ${type === "meal" ? "active" : ""}" href="#/kaynaklar/meal">Meal</a>
        <a class="chip ${type === "tefsir" ? "active" : ""}" href="#/kaynaklar/tefsir">Tefsir</a>
      </div>

      <button class="btn" id="addSourceBtn" style="margin-bottom:22px;">+ Kaynak Ekle</button>

      <div id="sourceList"></div>
    `;

    function renderList() {
      const listEl = document.getElementById("sourceList");
      if (sources.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state">
            <svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg>
            <h4>Henüz kaynak eklenmedi</h4>
            <p>Örnek bağlantı: https://raw.githubusercontent.com/kullaniciadi/repo-adi/main/data/${type}</p>
          </div>
        `;
        return;
      }
      listEl.innerHTML = sources.map((s) => `
        <div class="source-row ${activeSources[type] === s.id ? "active" : ""}">
          <div class="source-info">
            <div class="name">${escapeHtml(s.name)} ${activeSources[type] === s.id ? "· <span style=\"color:var(--gold)\">Aktif</span>" : ""}</div>
            <div class="url">${escapeHtml(s.baseUrl)}</div>
          </div>
          <div class="source-row-actions">
            ${activeSources[type] !== s.id ? `<button class="btn btn-sm" data-activate="${s.id}">Aktif Yap</button>` : ""}
            <button class="icon-btn btn-sm" data-delete="${s.id}" style="color:var(--maroon);">Sil</button>
          </div>
        </div>
      `).join("");

      listEl.querySelectorAll("[data-activate]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const updated = { ...activeSources, [type]: btn.dataset.activate };
          await DB.setSetting("activeSources", updated);
          toast("Aktif kaynak güncellendi");
          ViewSources.render(type);
        });
      });
      listEl.querySelectorAll("[data-delete]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await DB.delete("sources", btn.dataset.delete);
          if (activeSources[type] === btn.dataset.delete) {
            const updated = { ...activeSources };
            delete updated[type];
            await DB.setSetting("activeSources", updated);
          }
          toast("Kaynak silindi");
          ViewSources.render(type);
        });
      });
    }
    renderList();

    document.getElementById("addSourceBtn").addEventListener("click", () => {
      openModal(`
        <h3>${label.title.replace("ları", "").replace("leri", "")} Ekle</h3>
        <div class="field">
          <label>Kaynak Adı</label>
          <input type="text" id="srcName" placeholder="Örn: Diyanet Meali" />
        </div>
        <div class="field">
          <label>GitHub Klasör Bağlantısı (raw)</label>
          <input type="url" id="srcUrl" placeholder="https://raw.githubusercontent.com/kullanici/repo/main/data/${type}" />
        </div>
        <div class="modal-actions">
          <button class="btn btn-outline" data-close>Vazgeç</button>
          <button class="btn" id="srcSave">Ekle</button>
        </div>
      `, {
        onMount: (m, close) => {
          m.querySelector("[data-close]").addEventListener("click", close);
          m.querySelector("#srcSave").addEventListener("click", async () => {
            const name = m.querySelector("#srcName").value.trim();
            const baseUrl = m.querySelector("#srcUrl").value.trim();
            if (!name || !baseUrl) { toast("Ad ve bağlantı gerekli"); return; }
            const id = uid("src");
            await DB.put("sources", { id, type, name, baseUrl, createdAt: Date.now() });
            // İlk eklenen kaynak otomatik aktif olsun
            const current = await DB.getSetting("activeSources", {});
            if (!current[type]) {
              await DB.setSetting("activeSources", { ...current, [type]: id });
            }
            close();
            toast("Kaynak eklendi");
            ViewSources.render(type);
          });
        }
      });
    });
  }
};
