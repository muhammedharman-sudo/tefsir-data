/* app.js — Uygulama giriş noktası: rota tanımları + genel arayüz olayları */

Router.add("/home", (params) => ViewHome.render());
Router.add("/sureler", (params) => ViewSurahList.render());
Router.add("/sure/:no", (params) => ViewSurahRead.render(parseInt(params.no, 10)));

Router.add("/konular", (params) => ViewTopics.render());
Router.add("/konu/:id", (params) => ViewTopicDetail.render(params.id));

Router.add("/kumeler", (params) => ViewCollections.render());
Router.add("/kume/:id", (params) => ViewCollectionDetail.render(params.id));

Router.add("/kaynaklar/:type", (params) => ViewSources.render(params.type));

Router.add("/favoriler", (params) => ViewFavorites.render());
Router.add("/notlarim", (params) => ViewNotes.render());
Router.add("/yedekle", (params) => ViewBackup.render());

// ---- Üst menü (Daha) açılır kapanır ----
const moreBtn = document.getElementById("moreBtn");
const moreMenu = document.getElementById("moreMenu");
moreBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  const open = moreMenu.classList.toggle("open");
  moreBtn.setAttribute("aria-expanded", open);
});
document.addEventListener("click", () => moreMenu.classList.remove("open"));

// ---- Mobil hamburger menü ----
const hamburgerBtn = document.getElementById("hamburgerBtn");
const mobileMenu = document.getElementById("mobileMenu");
hamburgerBtn.addEventListener("click", () => mobileMenu.classList.toggle("open"));
mobileMenu.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => mobileMenu.classList.remove("open")));

// ---- Başlangıç: ilk kurulum kontrolü (örnek kaynak yoksa varsayılan ayarları oluştur) ----
async function bootstrap() {
  const existing = await DB.getAll("sources");
  if (existing.length === 0) {
    // Kullanıcı "Daha" menüsünden kendi GitHub repo bağlantılarını ekleyecek.
    // Burada sadece boş başlatıyoruz; sources.js sayfası ekleme formunu sunar.
  }
  Router.init();
}

bootstrap();
