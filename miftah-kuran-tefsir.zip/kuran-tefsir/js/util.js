/* util.js — Ortak yardımcı fonksiyonlar: toast bildirimi, basit modal, ayet aksiyonları */

function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2400);
}

function escapeHtml(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Basit modal: openModal(html içeriği, {onMount}) -> kapatma fonksiyonu döner
function openModal(innerHtml, { onMount } = {}) {
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `<div class="modal">${innerHtml}</div>`;
  document.body.appendChild(backdrop);

  const close = () => backdrop.remove();
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) close();
  });
  document.addEventListener("keydown", function escHandler(e) {
    if (e.key === "Escape") { close(); document.removeEventListener("keydown", escHandler); }
  });

  if (onMount) onMount(backdrop.querySelector(".modal"), close);
  return close;
}

/* ---------------- Ayet aksiyonları: Favori / Not / İlişkili Ayet ---------------- */

const AyetActions = {
  async isFavorite(sure, ayet) {
    const all = await DB.getAll("favorites");
    return all.find((f) => f.sure === sure && f.ayet === ayet) || null;
  },

  async toggleFavorite(sure, ayet, sureAdi) {
    const existing = await this.isFavorite(sure, ayet);
    if (existing) {
      await DB.delete("favorites", existing.id);
      toast("Favorilerden çıkarıldı");
      return false;
    } else {
      await DB.put("favorites", { id: uid("fav"), sure, ayet, sureAdi, createdAt: Date.now() });
      toast("Favorilere eklendi");
      return true;
    }
  },

  async getNotes(sure, ayet) {
    const all = await DB.getAll("notes");
    return all.filter((n) => n.sure === sure && n.ayet === ayet).sort((a, b) => b.createdAt - a.createdAt);
  },

  async addNote(sure, ayet, sureAdi, text) {
    if (!text || !text.trim()) return;
    await DB.put("notes", { id: uid("note"), sure, ayet, sureAdi, text: text.trim(), createdAt: Date.now() });
    toast("Not eklendi");
  },

  async deleteNote(id) {
    await DB.delete("notes", id);
    toast("Not silindi");
  },

  async getRelated(sure, ayet) {
    const all = await DB.getAll("related");
    return all.filter((r) => r.sureA === sure && r.ayetA === ayet);
  },

  async addRelated(sure, ayet, sureAdi, sureB, ayetB, sureBAdi, note = "") {
    await DB.put("related", {
      id: uid("rel"), sureA: sure, ayetA: ayet, sureAdi,
      sureB, ayetB, sureBAdi, note, createdAt: Date.now()
    });
    toast("İlişkili ayet eklendi");
  },

  async deleteRelated(id) {
    await DB.delete("related", id);
    toast("İlişkili ayet kaldırıldı");
  }
};

/* Bir ayet kartının altındaki aksiyon çubuğunu + açılır not/ilişkili panelini oluşturur.
   container: bu HTML'in ekleneceği DOM elemanı
   ctx: { sure, ayet, sureAdi } */
async function renderAyetActions(container, ctx) {
  const { sure, ayet, sureAdi } = ctx;
  const fav = await AyetActions.isFavorite(sure, ayet);
  const notes = await AyetActions.getNotes(sure, ayet);
  const related = await AyetActions.getRelated(sure, ayet);

  const wrap = document.createElement("div");
  wrap.innerHTML = `
    <div class="ayet-actions">
      <button class="icon-btn btn-fav ${fav ? "active" : ""}" type="button">
        <svg viewBox="0 0 24 24" fill="${fav ? "currentColor" : "none"}" stroke="currentColor" stroke-width="1.6"><path d="M12 20s-7-4.35-9.5-8.5C.7 8 2 4.5 5.5 4A5.4 5.4 0 0 1 12 7a5.4 5.4 0 0 1 6.5-3C22 4.5 23.3 8 21.5 11.5 19 15.65 12 20 12 20Z"/></svg>
        ${fav ? "Favoride" : "Favori"}
      </button>
      <button class="icon-btn btn-related" type="button">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="6" cy="12" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M8.6 10.6 15.4 7.4M8.6 13.4l6.8 3.2"/></svg>
        İlişkili Ayet ${related.length ? `(${related.length})` : ""}
      </button>
      <button class="icon-btn btn-note" type="button">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 4h16v12H8l-4 4V4Z"/></svg>
        Not Ekle ${notes.length ? `(${notes.length})` : ""}
      </button>
    </div>
    <div class="notes-slot"></div>
    <div class="related-slot"></div>
  `;
  container.appendChild(wrap);

  const notesSlot = wrap.querySelector(".notes-slot");
  const relatedSlot = wrap.querySelector(".related-slot");

  function renderNotesList(list) {
    notesSlot.innerHTML = list.map((n) => `
      <div class="note-box" data-note-id="${n.id}">
        <div>${escapeHtml(n.text)}</div>
        <div class="note-meta">${new Date(n.createdAt).toLocaleString("tr-TR")} · <a href="#" class="del-note" data-id="${n.id}">sil</a></div>
      </div>
    `).join("");
    notesSlot.querySelectorAll(".del-note").forEach((a) => {
      a.addEventListener("click", async (e) => {
        e.preventDefault();
        await AyetActions.deleteNote(a.dataset.id);
        const fresh = await AyetActions.getNotes(sure, ayet);
        renderNotesList(fresh);
      });
    });
  }

  function renderRelatedList(list) {
    relatedSlot.innerHTML = list.length ? `<div class="related-tags">${list.map((r) => `
      <span class="related-tag">${escapeHtml(r.sureBAdi)} ${r.ayetB} <a href="#" class="del-rel" data-id="${r.id}" style="margin-left:6px;opacity:.7">✕</a></span>
    `).join("")}</div>` : "";
    relatedSlot.querySelectorAll(".del-rel").forEach((a) => {
      a.addEventListener("click", async (e) => {
        e.preventDefault();
        await AyetActions.deleteRelated(a.dataset.id);
        const fresh = await AyetActions.getRelated(sure, ayet);
        renderRelatedList(fresh);
      });
    });
  }

  renderNotesList(notes);
  renderRelatedList(related);

  wrap.querySelector(".btn-fav").addEventListener("click", async () => {
    await AyetActions.toggleFavorite(sure, ayet, sureAdi);
    const btn = wrap.querySelector(".btn-fav");
    const nowFav = await AyetActions.isFavorite(sure, ayet);
    btn.classList.toggle("active", !!nowFav);
    btn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="${nowFav ? "currentColor" : "none"}" stroke="currentColor" stroke-width="1.6"><path d="M12 20s-7-4.35-9.5-8.5C.7 8 2 4.5 5.5 4A5.4 5.4 0 0 1 12 7a5.4 5.4 0 0 1 6.5-3C22 4.5 23.3 8 21.5 11.5 19 15.65 12 20 12 20Z"/></svg>
      ${nowFav ? "Favoride" : "Favori"}`;
  });

  wrap.querySelector(".btn-note").addEventListener("click", () => {
    openModal(`
      <h3>Not Ekle</h3>
      <p style="font-size:13px;color:#6B6350;margin-top:-8px">${escapeHtml(sureAdi)} Suresi, ${ayet}. Ayet</p>
      <div class="field">
        <label>Notunuz</label>
        <textarea id="noteText" placeholder="Bu ayetle ilgili düşüncelerinizi yazın..."></textarea>
      </div>
      <div class="modal-actions">
        <button class="btn btn-outline" data-close>Vazgeç</button>
        <button class="btn" id="saveNoteBtn">Kaydet</button>
      </div>
    `, {
      onMount: (modalEl, close) => {
        modalEl.querySelector("[data-close]").addEventListener("click", close);
        modalEl.querySelector("#saveNoteBtn").addEventListener("click", async () => {
          const val = modalEl.querySelector("#noteText").value;
          if (!val.trim()) return;
          await AyetActions.addNote(sure, ayet, sureAdi, val);
          close();
          const fresh = await AyetActions.getNotes(sure, ayet);
          renderNotesList(fresh);
          wrap.querySelector(".btn-note").innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 4h16v12H8l-4 4V4Z"/></svg>
            Not Ekle (${fresh.length})`;
        });
      }
    });
  });

  wrap.querySelector(".btn-related").addEventListener("click", () => {
    const options = SURAH_LIST.map((s) => `<option value="${s.no}">${s.no}. ${s.ad}</option>`).join("");
    openModal(`
      <h3>İlişkili Ayet Ekle</h3>
      <p style="font-size:13px;color:#6B6350;margin-top:-8px">${escapeHtml(sureAdi)} Suresi, ${ayet}. Ayet ile ilişkilendir</p>
      <div class="range-row">
        <div class="field">
          <label>Sure</label>
          <select id="relSure">${options}</select>
        </div>
        <div class="field">
          <label>Ayet No</label>
          <input type="text" id="relAyet" placeholder="Örn: 12" />
        </div>
      </div>
      <div class="field">
        <label>Not (opsiyonel)</label>
        <input type="text" id="relNote" placeholder="Neden ilişkili? (opsiyonel)" />
      </div>
      <div class="modal-actions">
        <button class="btn btn-outline" data-close>Vazgeç</button>
        <button class="btn" id="saveRelBtn">Ekle</button>
      </div>
    `, {
      onMount: (modalEl, close) => {
        modalEl.querySelector("[data-close]").addEventListener("click", close);
        modalEl.querySelector("#saveRelBtn").addEventListener("click", async () => {
          const sureB = parseInt(modalEl.querySelector("#relSure").value, 10);
          const ayetB = parseInt(modalEl.querySelector("#relAyet").value, 10);
          const note = modalEl.querySelector("#relNote").value;
          if (!sureB || !ayetB) { toast("Sure ve ayet numarası gerekli"); return; }
          const sureBAdi = SURAH_LIST.find((s) => s.no === sureB)?.ad || "";
          await AyetActions.addRelated(sure, ayet, sureAdi, sureB, ayetB, sureBAdi, note);
          close();
          const fresh = await AyetActions.getRelated(sure, ayet);
          renderRelatedList(fresh);
          wrap.querySelector(".btn-related").innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="6" cy="12" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M8.6 10.6 15.4 7.4M8.6 13.4l6.8 3.2"/></svg>
            İlişkili Ayet (${fresh.length})`;
        });
      }
    });
  });
}
