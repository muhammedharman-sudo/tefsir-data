/* router.js — Basit hash tabanlı yönlendirici.
   Rota tanımları app.js içinde Router.add(...) ile yapılır. */

const Router = {
  routes: [],

  add(pattern, handler) {
    // pattern örn: "/surah/:no" -> regex'e çevrilir
    const paramNames = [];
    const regexStr = "^" + pattern.replace(/:[^/]+/g, (m) => {
      paramNames.push(m.slice(1));
      return "([^/]+)";
    }) + "$";
    this.routes.push({ regex: new RegExp(regexStr), paramNames, handler });
  },

  async resolve() {
    const hash = location.hash.replace(/^#/, "") || "/home";
    const path = hash.split("?")[0];

    for (const route of this.routes) {
      const m = path.match(route.regex);
      if (m) {
        const params = {};
        route.paramNames.forEach((name, i) => (params[name] = decodeURIComponent(m[i + 1])));
        const app = document.getElementById("app");
        app.innerHTML = `<div class="loader"><svg viewBox="0 0 40 40"><use href="#rub-el-hizb"></use></svg><span>Yükleniyor…</span></div>`;
        window.scrollTo({ top: 0 });
        try {
          await route.handler(params);
        } catch (err) {
          console.error(err);
          app.innerHTML = `<div class="empty-state"><h4>Bir şeyler ters gitti</h4><p>${escapeHtml(err.message || String(err))}</p></div>`;
        }
        updateActiveNav(path);
        return;
      }
    }
    document.getElementById("app").innerHTML = `<div class="empty-state"><h4>Sayfa bulunamadı</h4></div>`;
  },

  init() {
    window.addEventListener("hashchange", () => this.resolve());
    this.resolve();
  }
};

function updateActiveNav(path) {
  document.querySelectorAll("[data-nav]").forEach((a) => a.classList.remove("active"));
  let key = null;
  if (path === "/home") key = "home";
  else if (path.startsWith("/sure")) key = "sureler";
  else if (path.startsWith("/kume")) key = "kumeler";
  else if (path.startsWith("/konu")) key = "konular";
  if (key) document.querySelectorAll(`[data-nav="${key}"]`).forEach((a) => a.classList.add("active"));
}
