/*
  db.js — Tarayıcı içi veritabanı (IndexedDB) katmanı.

  localStorage yerine IndexedDB kullanıyoruz çünkü:
  - localStorage ~5-10MB ile sınırlı ve senkron çalışır (arayüzü kilitleyebilir)
  - IndexedDB çok daha büyük kapasiteye sahiptir ve asenkron çalışır

  Depolanan tablolar (object store):
  - settings      : kaynak ayarları, aktif kaynak seçimleri, tema vs. (tek satırlık ayar objesi)
  - sources       : GitHub kaynakları (arapça/meal/tefsir kaynak listesi)
  - topics        : kullanıcı tanımlı konular ve bu konuya atanmış ayetler
  - collections   : kümeler (sure/ayet aralığı listeleri)
  - favorites     : favori ayetler
  - notes         : ayet notları
  - related       : ilişkili ayet bağlantıları
  - cache         : GitHub'dan çekilen sure verilerinin geçici önbelleği (tekrar indirmeyi azaltmak için)
*/

const DB_NAME = "kuran_tefsir_db";
const DB_VERSION = 1;

const STORES = ["settings", "sources", "topics", "collections", "favorites", "notes", "related", "cache"];

let _dbPromise = null;

function openDB() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("settings")) {
        db.createObjectStore("settings", { keyPath: "key" });
      }
      if (!db.objectStoreNames.contains("sources")) {
        db.createObjectStore("sources", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("topics")) {
        db.createObjectStore("topics", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("collections")) {
        db.createObjectStore("collections", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("favorites")) {
        const s = db.createObjectStore("favorites", { keyPath: "id" });
        s.createIndex("bySureAyet", ["sure", "ayet"], { unique: false });
      }
      if (!db.objectStoreNames.contains("notes")) {
        const s = db.createObjectStore("notes", { keyPath: "id" });
        s.createIndex("bySureAyet", ["sure", "ayet"], { unique: false });
      }
      if (!db.objectStoreNames.contains("related")) {
        const s = db.createObjectStore("related", { keyPath: "id" });
        s.createIndex("bySureAyetA", ["sureA", "ayetA"], { unique: false });
      }
      if (!db.objectStoreNames.contains("cache")) {
        db.createObjectStore("cache", { keyPath: "key" });
      }
    };

    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e.target.error);
  });
  return _dbPromise;
}

function tx(storeName, mode = "readonly") {
  return openDB().then((db) => db.transaction(storeName, mode).objectStore(storeName));
}

const DB = {
  // ---- Genel amaçlı yardımcılar ----
  async getAll(storeName) {
    const store = await tx(storeName);
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  },

  async get(storeName, key) {
    const store = await tx(storeName);
    return new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  },

  async put(storeName, value) {
    const store = await tx(storeName, "readwrite");
    return new Promise((resolve, reject) => {
      const req = store.put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  },

  async delete(storeName, key) {
    const store = await tx(storeName, "readwrite");
    return new Promise((resolve, reject) => {
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  async clear(storeName) {
    const store = await tx(storeName, "readwrite");
    return new Promise((resolve, reject) => {
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  // ---- Ayarlar (tek anahtar/değer) ----
  async getSetting(key, defaultValue = null) {
    const row = await DB.get("settings", key);
    return row ? row.value : defaultValue;
  },
  async setSetting(key, value) {
    return DB.put("settings", { key, value });
  },

  // ---- Yedekleme: tüm kullanıcı verisini tek JSON'a topla ----
  async exportAll() {
    const [sources, topics, collections, favorites, notes, related, settingsRaw] = await Promise.all([
      DB.getAll("sources"),
      DB.getAll("topics"),
      DB.getAll("collections"),
      DB.getAll("favorites"),
      DB.getAll("notes"),
      DB.getAll("related"),
      DB.getAll("settings")
    ]);
    return {
      _tip: "kuran-tefsir-yedek",
      _surum: 1,
      _tarih: new Date().toISOString(),
      sources,
      topics,
      collections,
      favorites,
      notes,
      related,
      settings: settingsRaw
    };
  },

  // ---- Geri yükleme: JSON'dan tüm kullanıcı verisini yaz ----
  async importAll(data, { overwrite = true } = {}) {
    if (!data || data._tip !== "kuran-tefsir-yedek") {
      throw new Error("Geçersiz yedek dosyası: '_tip' alanı 'kuran-tefsir-yedek' olmalı.");
    }
    if (overwrite) {
      await Promise.all(["sources", "topics", "collections", "favorites", "notes", "related", "settings"].map((s) => DB.clear(s)));
    }
    const writeAll = (storeName, rows) => Promise.all((rows || []).map((r) => DB.put(storeName, r)));
    await Promise.all([
      writeAll("sources", data.sources),
      writeAll("topics", data.topics),
      writeAll("collections", data.collections),
      writeAll("favorites", data.favorites),
      writeAll("notes", data.notes),
      writeAll("related", data.related),
      writeAll("settings", data.settings)
    ]);
  }
};

// Basit benzersiz kimlik üreteci
function uid(prefix = "id") {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
